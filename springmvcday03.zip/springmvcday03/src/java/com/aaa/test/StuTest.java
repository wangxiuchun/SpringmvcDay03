package com.aaa.test;

import com.aaa.service.StuService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StuTest {
    public static void main(String[] args) {
        //实例化spring容器
        ApplicationContext act = new ClassPathXmlApplicationContext("spring.xml");
        //通过id获得bean
        StuService stuService = (StuService)act.getBean("stuServiceImpl");
        stuService.selectStu();
    }
}
