package com.aaa.dao;

import org.springframework.stereotype.Repository;

@Repository
public class StuDaoImpl implements StuDao {

    @Override
    public void selectStu() {
        System.out.println("查询成功!!!!!!!!!!!!!!!");
    }
}
