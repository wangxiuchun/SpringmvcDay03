package com.aaa.dao;

public interface StuDao {
    public void selectStu();
}
