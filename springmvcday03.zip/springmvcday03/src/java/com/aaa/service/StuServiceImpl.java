package com.aaa.service;

import com.aaa.dao.StuDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StuServiceImpl implements StuService {
    @Autowired
    private StuDao dao;

    @Override
    public void selectStu() {
        dao.selectStu();
    }

    public void setDao(StuDao dao) {
        this.dao = dao;
    }
}
