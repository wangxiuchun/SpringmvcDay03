package com.aaa.service;

public interface StuService {
    public void selectStu();
}
