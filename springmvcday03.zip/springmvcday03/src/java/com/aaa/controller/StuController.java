package com.aaa.controller;

import com.aaa.entity.Student;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

@Controller
//@RequestMapping("/stu")
public class StuController {
    List<Student> list = new ArrayList<Student>();

    //查询
    @RequestMapping("/selectStu")
    public ModelAndView selectStu(){
        ModelAndView mav=new ModelAndView();
        //填充模型数据

        mav.addObject("list",list);
        //返回视图
        mav.setViewName("/qiantai/selectStu");
        return  mav;
    }

    //添加
    @RequestMapping("/addStu")
    public String addStu(Student student){
        System.out.println(student.getName());
        list.add(student);
        return "redirect:/selectStu.action";
    }

}
